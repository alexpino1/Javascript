let Nombre=" Walter_Alexander";
let Apellido="Pino_Vaquez ";
let estudiante=Nombre.concat(" ",Apellido);
console.log(estudiante)
let estudianteMayus=estudiante.toUpperCase(estudiante);
console.log(estudianteMayus)
let estudianteMinus=estudiante.toLowerCase(estudiante);
console.log(estudianteMinus)
let contarletras=estudiante.length;
console.log(contarletras);
console.log(Nombre.charAt(0));
console.log(estudiante.trim());
console.log(estudiante.includes("Walter_Alexander"));


